const CATEGORY_LABELS = {
  ones: "Einser",
  twos: "Zweier",
  threes: "Dreier",
  fours: "Vierer",
  fives: "Fuenfer",
  sixes: "Sechser",
  threeOfKind: "Dreierpasch",
  fourOfKind: "Viererpasch",
  fullHouse: "Full House",
  smallStraight: "Kleine Strasse",
  largeStraight: "Grosse Strasse",
  kniffel: "Kniffel",
  chance: "Chance"
};

const UPPER_CATEGORIES = ["ones", "twos", "threes", "fours", "fives", "sixes"];
const LOWER_CATEGORIES = ["threeOfKind", "fourOfKind", "fullHouse", "smallStraight", "largeStraight", "kniffel", "chance"];

const DOT_POSITIONS = {
  1: [[2, 2]],
  2: [[1, 3], [3, 1]],
  3: [[1, 3], [2, 2], [3, 1]],
  4: [[1, 1], [1, 3], [3, 1], [3, 3]],
  5: [[1, 1], [1, 3], [2, 2], [3, 1], [3, 3]],
  6: [[1, 1], [1, 3], [2, 1], [2, 3], [3, 1], [3, 3]]
};

function diceFaceHTML(value) {
  if (value < 1 || value > 6) {
    return '<div class="kniffel-die-grid"><div class="kniffel-die-empty">?</div></div>';
  }
  const dots = DOT_POSITIONS[value];
  let cells = "";
  for (let row = 1; row <= 3; row++) {
    for (let col = 1; col <= 3; col++) {
      const hasDot = dots.some(function (d) { return d[0] === row && d[1] === col; });
      cells += hasDot
        ? '<div class="kniffel-die-cell"><div class="kniffel-dot"></div></div>'
        : '<div class="kniffel-die-cell"></div>';
    }
  }
  return '<div class="kniffel-die-grid">' + cells + '</div>';
}

function valueOrDash(value) {
  return value === null || value === undefined ? "-" : String(value);
}

const KNIFFEL_CSS = `
@keyframes kniffel-roll {
  0% { transform: rotate(0deg) scale(1); }
  15% { transform: rotate(-14deg) scale(1.1); }
  30% { transform: rotate(10deg) scale(0.93); }
  45% { transform: rotate(-8deg) scale(1.06); }
  60% { transform: rotate(6deg) scale(0.97); }
  75% { transform: rotate(-3deg) scale(1.02); }
  100% { transform: rotate(0deg) scale(1); }
}

@keyframes kniffel-settle {
  0% { transform: translateY(-4px); }
  100% { transform: translateY(0); }
}

.kniffel-status {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
  padding: 0.75rem 1rem;
  font-size: 0.9rem;
  color: var(--color-text-muted);
}

.kniffel-status strong {
  color: var(--color-text);
}

.kniffel-my-turn {
  color: var(--color-success);
  font-weight: 600;
}

.kniffel-dice-area {
  margin-bottom: 1rem;
}

.kniffel-dice-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-bottom: 1rem;
  justify-content: center;
}

.kniffel-die {
  width: 64px;
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  user-select: none;
  transition: transform var(--transition), border-color var(--transition), box-shadow var(--transition);
}

.kniffel-die:hover:not(.kniffel-die--disabled) {
  transform: translateY(-2px);
}

.kniffel-die-face {
  width: 60px;
  height: 60px;
  border-radius: var(--radius);
  background-color: var(--color-bg-secondary);
  border: 2px solid var(--color-border);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: border-color var(--transition), background-color var(--transition), box-shadow var(--transition);
}

.kniffel-die--held .kniffel-die-face {
  border-color: var(--color-primary);
  background-color: var(--color-bg-hover);
  box-shadow: 0 0 8px rgba(99, 102, 241, 0.3);
}

.kniffel-die--rolling .kniffel-die-face {
  animation: kniffel-roll 0.5s ease-out;
}

.kniffel-die--settled .kniffel-die-face {
  animation: kniffel-settle 0.2s ease-out;
}

.kniffel-die--disabled {
  cursor: default;
  opacity: 0.5;
}

.kniffel-die-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(3, 1fr);
  width: 42px;
  height: 42px;
  gap: 1px;
}

.kniffel-die-cell {
  display: flex;
  align-items: center;
  justify-content: center;
}

.kniffel-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: var(--color-text);
}

.kniffel-die--held .kniffel-dot {
  background-color: var(--color-primary);
}

.kniffel-die-empty {
  color: var(--color-text-muted);
  font-size: 1.2rem;
  font-weight: 600;
}

.kniffel-table-wrap {
  overflow-x: auto;
  margin-top: 0.5rem;
}

.kniffel-scoreboard {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.85rem;
}

.kniffel-scoreboard th,
.kniffel-scoreboard td {
  padding: 0.4rem 0.6rem;
  border-bottom: 1px solid var(--color-border);
  text-align: center;
  white-space: nowrap;
}

.kniffel-scoreboard th {
  color: var(--color-text-muted);
  font-weight: 600;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding-bottom: 0.6rem;
}

.kniffel-scoreboard th:first-child,
.kniffel-scoreboard td:first-child {
  text-align: left;
  color: var(--color-text-muted);
}

.kniffel-scoreboard td {
  color: var(--color-text);
}

.kniffel-col-active {
  background-color: rgba(99, 102, 241, 0.1);
}

.kniffel-cell-filled {
  color: var(--color-text-muted);
  opacity: 0.6;
}

.kniffel-cell-preview {
  color: var(--color-primary);
  font-weight: 600;
  cursor: pointer;
  transition: background-color var(--transition), color var(--transition), transform var(--transition);
  border-radius: 4px;
  position: relative;
  background-color: rgba(99, 102, 241, 0.08);
}

.kniffel-cell-preview:hover {
  background-color: rgba(99, 102, 241, 0.2);
  color: #818cf8;
  transform: scale(1.1);
}

.kniffel-cell-empty {
  color: var(--color-border);
  opacity: 0.35;
}

.kniffel-row-separator td {
  border-bottom: 2px solid var(--color-border);
  padding-top: 0.2rem;
  padding-bottom: 0.2rem;
  height: 4px;
}

.kniffel-row-subtotal td {
  font-weight: 600;
  color: var(--color-text);
}

.kniffel-row-total td {
  font-weight: 700;
  color: var(--color-primary);
  font-size: 0.95rem;
  border-bottom: none;
}

.kniffel-gameover {
  margin-top: 1rem;
  text-align: center;
}

.kniffel-gameover h2 {
  color: var(--color-success);
  margin-bottom: 0.75rem;
}

.kniffel-ranking {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-top: 1rem;
}

.kniffel-ranking-entry {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem 0.75rem;
  border-radius: var(--radius);
  background-color: var(--color-bg-secondary);
  border: 1px solid var(--color-border);
}

.kniffel-ranking-entry--winner {
  border-color: var(--color-success);
  background-color: rgba(34, 197, 94, 0.08);
}

.kniffel-ranking-place {
  font-weight: 700;
  color: var(--color-text-muted);
  min-width: 2rem;
}

.kniffel-ranking-name {
  flex: 1;
  color: var(--color-text);
  font-weight: 600;
}

.kniffel-ranking-score {
  color: var(--color-primary);
  font-weight: 700;
}

.kniffel-btn-row {
  display: flex;
  justify-content: center;
}

.kniffel-info {
  text-align: center;
  padding: 1.5rem;
  color: var(--color-text-muted);
}

.kniffel-error {
  color: var(--color-danger);
  font-weight: 600;
  margin-bottom: 0.75rem;
}

.kniffel-btn-roll:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
`;

export default {
  template: `
    <div>
      <p v-if="error" class="kniffel-error">{{ error }}</p>

      <div v-if="!state" class="card">
        <div class="kniffel-info">Lade Spielstand...</div>
      </div>

      <template v-else>
        <div class="card kniffel-status">
          <span>Am Zug: <strong>{{ state.currentPlayerName || '-' }}</strong></span>
          <span>Wuerfe uebrig: <strong>{{ state.rollsLeft }}</strong></span>
          <span v-if="state.gameOver" style="color: var(--color-warning); font-weight: 600;">Spiel beendet</span>
          <span v-else-if="isMyTurn" class="kniffel-my-turn">Du bist dran!</span>
        </div>

        <div class="card kniffel-dice-area">
          <div class="kniffel-dice-row">
            <div
              v-for="(die, i) in state.dice"
              :key="i"
              class="kniffel-die"
              :class="{
                'kniffel-die--held': state.held[i],
                'kniffel-die--rolling': isRolling && !state.held[i],
                'kniffel-die--settled': justSettled && !state.held[i],
                'kniffel-die--disabled': !canToggleHold
              }"
              @click="toggleHold(i)"
            >
              <div class="kniffel-die-face" v-html="getDiceFace(die)"></div>
            </div>
          </div>
          <div v-if="!state.gameOver" class="kniffel-btn-row">
            <button class="btn-primary kniffel-btn-roll" :disabled="!canRoll" @click="rollDice">
              {{ rollButtonText }}
            </button>
          </div>
        </div>

        <div class="card">
          <h3 style="margin-top: 0; margin-bottom: 0.5rem; color: var(--color-text);">Scoreboard</h3>
          <p v-if="isMyTurn && state.rollsLeft < 3 && !state.gameOver" style="margin: 0 0 0.5rem; font-size: 0.8rem; color: var(--color-text-muted);">
            Klicke in deiner Spalte auf eine Kategorie, um einzutragen.
          </p>
          <div class="kniffel-table-wrap">
            <table class="kniffel-scoreboard">
              <thead>
                <tr>
                  <th>Kategorie</th>
                  <th
                    v-for="p in state.players"
                    :key="p.userId"
                    :class="headerClasses(p.userId)"
                  >
                    {{ p.username }}
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="cat in upperCategories" :key="cat">
                  <td>{{ labelFor(cat) }}</td>
                  <td
                    v-for="p in state.players"
                    :key="p.userId"
                    :class="cellClasses(p.userId, cat)"
                    @click="onCellClick(p.userId, cat)"
                  >
                    {{ displayScore(p.userId, cat) }}
                  </td>
                </tr>
                <tr class="kniffel-row-separator"><td :colspan="1 + state.players.length"></td></tr>
                <tr class="kniffel-row-subtotal">
                  <td>Oben Summe</td>
                  <td
                    v-for="p in state.players"
                    :key="p.userId"
                    :class="headerClasses(p.userId)"
                  >
                    {{ subtotalFor(p.userId, 'upperSubtotal') }}
                  </td>
                </tr>
                <tr class="kniffel-row-subtotal">
                  <td>Bonus (ab 63)</td>
                  <td
                    v-for="p in state.players"
                    :key="p.userId"
                    :class="headerClasses(p.userId)"
                  >
                    {{ subtotalFor(p.userId, 'upperBonus') }}
                  </td>
                </tr>
                <tr class="kniffel-row-separator"><td :colspan="1 + state.players.length"></td></tr>
                <tr v-for="cat in lowerCategories" :key="cat">
                  <td>{{ labelFor(cat) }}</td>
                  <td
                    v-for="p in state.players"
                    :key="p.userId"
                    :class="cellClasses(p.userId, cat)"
                    @click="onCellClick(p.userId, cat)"
                  >
                    {{ displayScore(p.userId, cat) }}
                  </td>
                </tr>
                <tr class="kniffel-row-separator"><td :colspan="1 + state.players.length"></td></tr>
                <tr class="kniffel-row-subtotal">
                  <td>Unten Summe</td>
                  <td
                    v-for="p in state.players"
                    :key="p.userId"
                    :class="headerClasses(p.userId)"
                  >
                    {{ subtotalFor(p.userId, 'lowerSubtotal') }}
                  </td>
                </tr>
                <tr class="kniffel-row-total">
                  <td>Gesamt</td>
                  <td
                    v-for="p in state.players"
                    :key="p.userId"
                    :class="headerClasses(p.userId)"
                  >
                    {{ subtotalFor(p.userId, 'total') }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div v-if="gameOverData" class="card kniffel-gameover">
          <h2>Spiel beendet!</h2>
          <div class="kniffel-ranking">
            <div
              v-for="(entry, i) in gameOverData.ranking"
              :key="entry.userId"
              class="kniffel-ranking-entry"
              :class="{ 'kniffel-ranking-entry--winner': gameOverData.winners.includes(entry.userId) }"
            >
              <span class="kniffel-ranking-place">{{ i + 1 }}.</span>
              <span class="kniffel-ranking-name">{{ entry.username }}</span>
              <span class="kniffel-ranking-score">{{ entry.total }} Punkte</span>
            </div>
          </div>
        </div>
      </template>
    </div>
  `,

  data() {
    return {
      socketRef: null,
      state: null,
      canAct: false,
      error: "",
      isRolling: false,
      justSettled: false,
      prevDice: null,
      gameOverData: null,
      styleEl: null
    };
  },

  computed: {
    myUserId() {
      return (typeof window !== "undefined" && window.currentUserId) || "";
    },
    isMyTurn() {
      return this.canAct && !!this.state && !this.state.gameOver;
    },
    canRoll() {
      return this.isMyTurn && this.state.rollsLeft > 0 && !this.isRolling;
    },
    canToggleHold() {
      return this.isMyTurn && this.state.rollsLeft < 3;
    },
    rollButtonText() {
      if (!this.state) return "Wuerfeln";
      if (!this.isMyTurn) return "Warte...";
      if (this.state.rollsLeft === 0) return "Kategorie waehlen";
      if (this.state.rollsLeft === 3) return "Wuerfeln (3)";
      return "Neu wuerfeln (" + this.state.rollsLeft + ")";
    },
    upperCategories() {
      return UPPER_CATEGORIES;
    },
    lowerCategories() {
      return LOWER_CATEGORIES;
    }
  },

  mounted() {
    if (typeof socket === "undefined" || !socket) {
      this.error = "Socket-Verbindung nicht verfuegbar.";
      return;
    }

    this.injectStyles();
    this.socketRef = socket;

    this.onStateHandler = (payload) => {
      var oldDice = this.prevDice;
      var newDice = payload && payload.dice;
      var diceChanged = false;
      if (oldDice && newDice) {
        for (var i = 0; i < newDice.length; i++) {
          if (oldDice[i] !== newDice[i]) { diceChanged = true; break; }
        }
      }
      this.prevDice = newDice ? newDice.slice() : null;

      if (diceChanged && !this.isRolling) {
        this.isRolling = true;
        this.justSettled = false;
        setTimeout(() => {
          this.isRolling = false;
          this.justSettled = true;
          setTimeout(() => { this.justSettled = false; }, 200);
        }, 500);
      }

      this.state = payload;
      this.error = "";
    };
    this.onErrorHandler = (payload) => {
      this.error = (payload && typeof payload.message === "string")
        ? payload.message
        : "Unbekannter Fehler.";
    };
    this.onTurnPermissionHandler = (payload) => {
      this.canAct = !!(payload && payload.canAct);
    };
    this.onGameOverHandler = (payload) => {
      this.canAct = false;
      this.gameOverData = payload || null;
    };

    this.socketRef.on("plugin:kniffel:state", this.onStateHandler);
    this.socketRef.on("plugin:kniffel:error", this.onErrorHandler);
    this.socketRef.on("plugin:kniffel:turn-permission", this.onTurnPermissionHandler);
    this.socketRef.on("plugin:kniffel:game-over", this.onGameOverHandler);

    this.emitGameEvent("init-request", {});
  },

  beforeUnmount() {
    this.teardownSocketListeners();
    this.removeStyles();
  },

  beforeDestroy() {
    this.teardownSocketListeners();
    this.removeStyles();
  },

  methods: {
    injectStyles() {
      if (this.styleEl) return;
      this.styleEl = document.createElement("style");
      this.styleEl.setAttribute("data-kniffel", "");
      this.styleEl.textContent = KNIFFEL_CSS;
      document.head.appendChild(this.styleEl);
    },

    removeStyles() {
      if (this.styleEl && this.styleEl.parentNode) {
        this.styleEl.parentNode.removeChild(this.styleEl);
        this.styleEl = null;
      }
    },

    teardownSocketListeners() {
      if (!this.socketRef || typeof this.socketRef.off !== "function") return;
      if (this.onStateHandler) this.socketRef.off("plugin:kniffel:state", this.onStateHandler);
      if (this.onErrorHandler) this.socketRef.off("plugin:kniffel:error", this.onErrorHandler);
      if (this.onTurnPermissionHandler) this.socketRef.off("plugin:kniffel:turn-permission", this.onTurnPermissionHandler);
      if (this.onGameOverHandler) this.socketRef.off("plugin:kniffel:game-over", this.onGameOverHandler);
    },

    emitGameEvent(event, data) {
      if (!this.socketRef) return;
      this.socketRef.emit("game:event", { event, data });
    },

    getDiceFace(value) {
      return diceFaceHTML(value);
    },

    headerClasses(userId) {
      if (this.state && userId === this.state.currentPlayerId && !this.state.gameOver) return "kniffel-col-active";
      return "";
    },

    labelFor(category) {
      return CATEGORY_LABELS[category] || category;
    },

    displayScore(userId, category) {
      if (!this.state || !this.state.scores[userId]) return "-";
      var stored = this.state.scores[userId][category];
      if (stored !== null && stored !== undefined) return String(stored);

      if (this.isCellClickable(userId, category)) {
        var preview = this.state.previewScores && this.state.previewScores[category];
        return preview !== null && preview !== undefined ? String(preview) : "0";
      }
      return "-";
    },

    subtotalFor(userId, key) {
      if (!this.state || !this.state.scores[userId]) return "0";
      return valueOrDash(this.state.scores[userId][key]);
    },

    isCellClickable(userId, category) {
      if (!this.state || this.state.gameOver) return false;
      if (userId !== this.myUserId) return false;
      if (!this.canAct) return false;
      if (this.state.rollsLeft >= 3) return false;
      var stored = this.state.scores[userId] && this.state.scores[userId][category];
      return stored === null || stored === undefined;
    },

    cellClasses(userId, category) {
      var classes = [];
      if (this.state && userId === this.state.currentPlayerId && !this.state.gameOver) classes.push("kniffel-col-active");

      if (!this.state || !this.state.scores[userId]) return classes.join(" ");
      var stored = this.state.scores[userId][category];

      if (stored !== null && stored !== undefined) {
        classes.push("kniffel-cell-filled");
      } else if (this.isCellClickable(userId, category)) {
        classes.push("kniffel-cell-preview");
      } else {
        classes.push("kniffel-cell-empty");
      }
      return classes.join(" ");
    },

    onCellClick(userId, category) {
      if (!this.isCellClickable(userId, category)) return;
      this.emitGameEvent("score-category", { category: category });
    },

    rollDice() {
      if (!this.canRoll) return;
      this.emitGameEvent("roll-dice", {});
    },

    toggleHold(index) {
      if (!this.canToggleHold) return;
      this.emitGameEvent("toggle-hold", { index: index });
    }
  }
};
