export default {
  template: `
    <div>
      <h3 style="margin-top: 0; margin-bottom: 1rem; color: var(--color-text);">Kniffel-Einstellungen</h3>

      <div style="display: flex; flex-wrap: wrap; gap: 1rem; margin-bottom: 1rem;">
        <div style="flex: 0 0 160px;">
          <label>Mindestanzahl Spieler</label>
          <input
            type="number"
            v-model.number="minPlayers"
            min="1"
            max="10"
            @change="saveMinPlayers"
          />
        </div>
        <div style="flex: 0 0 160px;">
          <label>Maximale Spieleranzahl</label>
          <input
            type="number"
            v-model.number="maxPlayers"
            min="1"
            max="10"
            @change="saveMaxPlayers"
          />
        </div>
      </div>

      <p v-if="error" style="color: var(--color-danger); font-weight: 600;">{{ error }}</p>
      <p v-if="status" style="color: var(--color-success); font-weight: 600;">{{ status }}</p>
    </div>
  `,

  data() {
    return {
      minPlayers: 2,
      maxPlayers: 4,
      status: '',
      error: ''
    };
  },

  async mounted() {
    await this.load();
  },

  methods: {
    async load() {
      try {
        var res = await fetch('/api/plugins/kniffel/settings', { credentials: 'include' });
        var json = await res.json();
        if (json.data) {
          if (typeof json.data.minPlayers === 'number') this.minPlayers = json.data.minPlayers;
          if (typeof json.data.maxPlayers === 'number') this.maxPlayers = json.data.maxPlayers;
        }
      } catch (e) {
        this.error = 'Einstellungen konnten nicht geladen werden.';
      }
    },

    async save(key, value) {
      this.error = '';
      this.status = '';
      try {
        await fetch('/api/plugins/kniffel/settings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ key: key, value: value })
        });
        this.status = 'Gespeichert';
        setTimeout(() => { this.status = ''; }, 2000);
      } catch (e) {
        this.error = 'Speichern fehlgeschlagen.';
      }
    },

    saveMinPlayers() {
      if (this.minPlayers < 1) this.minPlayers = 1;
      if (this.minPlayers > this.maxPlayers) this.maxPlayers = this.minPlayers;
      this.save('minPlayers', this.minPlayers);
    },

    saveMaxPlayers() {
      if (this.maxPlayers < 1) this.maxPlayers = 1;
      if (this.maxPlayers < this.minPlayers) this.minPlayers = this.maxPlayers;
      this.save('maxPlayers', this.maxPlayers);
    }
  }
};
